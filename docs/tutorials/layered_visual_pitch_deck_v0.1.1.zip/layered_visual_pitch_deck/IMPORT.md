# Importing `layered_visual_pitch_deck` into your KairosChain

An L1 knowledge entry with a runnable kit: how to build a talk deck that is understood in one pass
(main slides, details pages, an appendix found with the up arrow, honesty on the slide). The hands-on
tutorial deck was built with it.

**This is an L1 knowledge entry, not a SkillSet.** It adds knowledge your agent reads, plus scripts
you run; it adds no MCP tools. (A SkillSet adds tools and is installed with
`kairos-chain skillset install <dir>`.)

Requirements: kairos-chain (tested with 3.93.0); Python 3 with `playwright` (then
`python3 -m playwright install chromium`), `qrcode` and `Pillow`; macOS for `qr_decode.swift`.
It builds on `html_slide_deck_authoring`, which ships with the gem (installed by `kairos-chain init`
and `kairos-chain upgrade --apply`).

## Steps (in your project root)

1. Download and unzip:

   ```sh
   U=https://masaomi.github.io/KairosChain_2026/tutorials
   curl -LO $U/layered_visual_pitch_deck_v0.1.1.zip && unzip layered_visual_pitch_deck_v0.1.1.zip
   ```

2. In Claude Code:
   "Create the L1 knowledge entry layered_visual_pitch_deck from
   layered_visual_pitch_deck/layered_visual_pitch_deck.md, with create_subdirs true."
   The agent calls `knowledge_update(command: "create", ...)`; the hash of the entry's text is
   recorded on your chain.
3. Copy the kit into the entry and check it:

   ```sh
   K=.kairos/knowledge/layered_visual_pitch_deck
   cp layered_visual_pitch_deck/scripts/* $K/scripts/
   cp layered_visual_pitch_deck/assets/* $K/assets/
   cp layered_visual_pitch_deck/references/* $K/references/
   (cd $K/scripts && for f in *.py *.swift; do echo "$(shasum -a 256 $f | cut -c1-16)  $f"; done)
   ```

   The chain records the `.md` only. Each 16-character prefix printed must equal the one in § 9 of
   the entry, which is how the kit files are checked.
4. Try it in a scratch folder (the kit writes `deck.html` and `shots/` where it runs):

   ```sh
   mkdir -p deck_try && cp $K/scripts/* deck_try/ && cd deck_try
   python3 make_deck_example.py && python3 check.py deck.html     # expect 0 issues on 4 pages
   python3 render.py deck.html 1                                  # PNG in shots/
   ```

5. Delete the unzipped folder, the zip and `deck_try/` when done. To start your own deck, ask Claude
   Code to "use the layered_visual_pitch_deck knowledge" for it.
