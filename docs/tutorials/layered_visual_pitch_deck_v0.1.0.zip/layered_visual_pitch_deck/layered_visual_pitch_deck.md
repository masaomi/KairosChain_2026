---
name: layered_visual_pitch_deck
description: "Use when a talk or pitch deck must be understood in one pass by a mixed audience and survive hard questions. Three layers (main slides carry one claim and one figure; claim-bearing slides have a details page; an appendix answers the expected questions and is found by pressing the up arrow), honesty shown on the slide itself, speaker notes and a source sheet, live-demo rules, and a public copy behind a cover QR code. Ships a runnable kit. Builds on html_slide_deck_authoring for the mechanics (modules, numbers, animation, checkers, PDF)."
version: "0.1.0"
layer: L1
tags: [slides, pitch, presentation, html, svg, honesty, speaker-notes, live-demo, qr, publication, kit]
related: [html_slide_deck_authoring, report_then_deck_pipeline, frontend_design, pitch_presentation_design]
---

# Layered visual pitch deck

## 要約（人向け）

本編は 1 枚に主張 1 つと図 1 つ、詳しい説明は主張のあるスライドの裏の「詳細」ページへ、予想される質問の
答えは付録へ置き、↑ キーで検索して飛べるようにする。スライドの言葉は、それだけ読んでも言い過ぎに
ならないようにする（限界は一言でもスライドに書き、詳細ページで説明する。発表メモだけに置かない）。数字は出どころの一覧に 1 行ずつ。
道具一式は `scripts/`、作例は `scripts/make_deck_example.py`。

## When to use

- A talk where the audience mixes specialists and non-specialists, and the hard questions come after.
- A deck that will be published (website, QR on the cover) and read later without the speaker.

Not for: Markdown slide tools, or deciding what the talk argues. For the mechanics of an HTML deck
(module split, how numbers are written, animation safety, checkers, PDF) follow
`html_slide_deck_authoring`; this entry assumes it and adds the structure, the honesty devices,
the notes, the demos and the publication.

**The governing invariant: a slide's own words and marks (a ✓, a rising curve) are true for a reader who
never opens another page and never hears the speaker.** A limit without which the slide would say more than was shown is on the
slide, at least as a scope word or a short line; the details page explains and sources it, and never
corrects the slide. The rest of this entry is how that is kept while the slides stay light.

---

## 1. Three layers

```
main slide  (one claim, one figure, said in ~1–3 min)
   │ "details" link in the footer            ▲ "back to main"
   ▼                                         │
details page (one per claim-bearing main slide: the table, the sources, "what it does not show")
   │ links in the details text
   ▼
appendix    (one page per expected hard question; drawn where a drawing carries it)

Press ↑ anywhere: a list of every page, filtered by any word on it; Enter jumps.
```

- Every claim-bearing main slide has a deeper page one click away; a title or closing slide needs none.
  Depth is moved behind the slide, never deleted to make the slide short.
- **File order: all main slides first, then the details pages, then the appendix.** The arrow keys
  step through the file in order; a details page placed after its main slide would interrupt the talk.
- Main slide keys start with `m` (End jumps to the last of them). A details page is labelled by its
  main slide in the index ("10 det") when its page label starts with `D` and it has a `back` link.

## 2. A main slide

- The **title is the claim**, a full sentence ("Today, the audit trail is the operator's own word"),
  not a topic ("Audit trails").
- **One figure** fills the slide (`vslide`: title + one full-bleed SVG). Any short source or scope
  line is drawn inside that SVG (`vslide` has no footnote slot).
- **Animation order is speaking order.**
- **Abstract categories get one everyday example each**, on the slide: "evidential (e.g. a log)",
  "constitutive (e.g. a certificate, a marriage registration)".
- **Two-act slides** for contrasts: "Normally …" then "But …".
- **The punchline gets its follow-up underneath** when the audience's next worry is predictable.
  The follow-up carries its scope on the slide ("lighter regulation", not "none"); the details page
  explains the limit (e.g. which laws still apply).
- **Social proof sits in a corner** (a repository link, "downloads" with a curve labelled cumulative);
  its source and what it does not mean ("downloads, not users") are on the details page.
- **Abstract pairs can be personified** with a matched pair of generated icons (`icon_img`). Embed a
  re-encoded copy (e.g. resized WebP), never the generator's original file, which can carry
  provenance metadata — and say on the details page that the icons were generated, and with what.
- **Name a partner only where they have agreed to be named** — including the cover subtitle and the
  footer (`kit.FOOT_TITLE`), which repeat on every page. On a problem slide name the generic actor
  only if the problem is true of that category, not just of one partner.

## 3. Honesty on the slide

What would change how the audience reads a slide is on that slide; its details page explains it.

| Situation | On the slide |
|---|---|
| Built but not running | An orange pill: "not deployed yet", "tested on X · not deployed yet" |
| Done but not yet recorded or published | "results not yet on our public log" |
| The same party wrote the test, built the tool and graded it | The title says so: "self-evaluation" |
| A test case left out of a count | Allowed only if it was declared out of reach **before the run, in a dated record the audience can check** (e.g. time-stamped expectations). The slide shows the case, marks it "declared out of reach before the run", and keeps the full count visible ("6 / 7 caught; 1 of 8 declared out of reach"). Never show the fraction without the excluded case beside it |
| A number that is your own measurement | Say so ("We checked 1,000 real … preprints") with a line naming the source, the period and who or what did the reading — "read by a model" if a model read them |
| A number that is someone else's | The population it was measured on, on the slide ("notebooks on GitHub"); the reference on the details page; the source row in SOURCES.md |

Scope every comparative claim on the slide itself: "lighter regulation", not "unregulated";
"downloads", not "users"; "the checker needs no data", not "reproducible without data".
Each details page has a **"What it does not show"** box beside what it shows.

## 4. Details and appendix pages

- A details page holds what the main slide compresses: the table behind the figure, the sources,
  the run command, the limits. Title = the main slide's title; kicker = "Details · slide N".
- An appendix page answers one expected question. The **hardest expected question gets a drawn
  page**: concede what is the same first, then draw the differences row by row, then one closing
  line. Do not claim the other approach cannot do it (example: "private chain vs Git" — the same
  mechanism; the difference is the arrangement of witnesses around it, which could also be built
  around Git).
- Cross-link both ways: main → details (footer), details → main (back), details → appendix (text),
  appendix → main (a "back to slide N" pill).

## 5. Speaker notes and the source sheet

Two Markdown files next to the deck, never published (templates in `assets/`):

- `rehearsal_notes.md` (from `assets/speaker_notes_template.md`) — one row per main slide: time,
  **the one sentence to land**, **do / avoid**. Then a "never say" list, then the expected questions
  grouped by who asks (developers D1…, management M1…, the question everyone asks G1…), each with a
  one-sentence answer and where to point in the deck.
- `SOURCES.md` (from `assets/SOURCES_template.md`) — **one row per number, quotation or asset on a
  slide**; a number without a row does not go on the slide.

The notes may repeat a limit; they are never its only home. When rehearsing raises a question
("where does this number come from?", "what is the difference between demo 1 and demo 3?"), the
answer goes on the slide (at least as a scope word) and is explained on a details or appendix page if
it changes how a slide reads; otherwise it goes to the notes.

## 6. Live demos

No demo script ships with the kit; these are the rules a demo script follows.

- **Numbered steps, one line each: OK (checked against what), READ (read from a local file, not
  checked), FAIL, SKIP (with the reason).** Say on screen which steps need the network, a partner
  account, or only local files.
- **A third party being down must not stop the demo**: catch the error in that step, print
  `SKIP <who> did not answer (<error type>)`, continue. A mode without that party's key skips the
  step instantly (a timeout costs ~10 s on stage).
- **End by naming what was not checked** whenever a step printed SKIP or READ.
- Keep a screenshot of a good run. If the live run fails, show it, say it is an earlier run and when it
  was made, and move on; do not debug on stage.
- Do not open any third-party page live if it shows internal details (paths, client names).

## 7. Public copy and the cover QR

```
choose NAME ─► cover QR encodes <host>/<NAME>.html (kit.qr_svg) ─► render, decode the QR from the PNG
        │
make_public.py ─► a new public_out_<time>/ folder: presenter-only lines dropped, companion pages
        │          renamed, local traces refused (in the deck and in companion pages)
        ▼
the operator copies that folder's files to the web server (an outward action: theirs, not the agent's)
        │
fetch the QR's URL and each file, compare byte for byte, open in a browser, try ↑
        │
after any later edit: make_public.py again, copy again
```

- Companion pages are copied byte for byte; links inside them are not rewritten. A page shown verbatim
  (e.g. a signed record, whose fingerprint covers its bytes) is listed in `VERBATIM`; its traces are
  printed for the operator instead of refused. Publishing only its fingerprint and a verifier link is
  the alternative.
- Before the copy, list for the operator what the public copy contains that a partner might not want
  public (links into the partner's system, run identifiers, a failed run, prices, plans, the partner's
  name on every footer, partner names in local file names that companion pages link to), and let them
  decide.
- Withholding is allowed; favour is not. If something is left out of the public copy, remove or scope
  every claim that depends on it.

## 8. Working loop

```
back up make_deck.py (timestamped copy in /tmp) ─► edit ─► python3 make_deck.py
   ─► python3 check.py deck.html (0 issues) ─► python3 render.py deck.html <n…> ─► look at each PNG
   ─► (if public) python3 make_public.py
```

- `make_deck.py` is your copy of `make_deck_example.py`, run in the folder that holds the kit.
- `check.py` finds HTML text-box overflow and SVG text outside x 40–1236 or outside a ≥150 px card in
  the same group. It does not see the cover title, narrow pills or text in shifted groups — so look at
  the PNG of every slide you changed.
- When the operator sends a new request mid-task, finish the current edit to a passing check first.

## 9. The kit (`scripts/`)

| File | What it does | SHA-256 (first 16) |
|---|---|---|
| `kit.py` | CSS, navigation JS (← → Space, Home/End, click, the ↑ index), `vslide` (no footnote) / `slide` (with a footnote line) / `hslide` / `page`, `qr_svg`, `icon_img`. Set `kit.FOOT_TITLE` | `578a0c46d4f89893` |
| `viz.py` | SVG helpers: text `T`, animation wrapper `A`, icons (person, doc, fingerprint, gear, clock, lock, stamp, …), `pill`, `badge`, `arrow_path` (arrowheads only in the palette colours), `chain` | `c51aa7431fcbc1cc` |
| `make_deck_example.py` | The smallest deck in this form: cover with QR, one main slide with a status pill, its details page, one appendix page | `214ee214951b0c75` |
| `check.py` | Layout check in headless Chromium (coverage as in § 8) | `8d2329722de11bf1` |
| `render.py` | `render.py <html> [n…]`: PNGs of slides n (1-based) into `shots/` | `e5693c26978ce668` |
| `make_public.py` | The public copy (§ 7) | `249354d68c7b6b0e` |
| `qr_decode.swift` | Decode a QR code from a rendered PNG (macOS) | `932e874b8943d21f` |

Needs Python 3 with `playwright` (Chromium installed) and `qrcode`; Pillow to resize icons.
To confirm the kit works: `python3 make_deck_example.py && python3 check.py deck.html` (expect
0 issues on 4 pages), `python3 render.py deck.html 1` and decode `shots/deck_01.png`, then
`python3 make_public.py` (expect a new `public_out_<time>/` holding `my_talk.html`). This was run by
the authoring session and by review personas of the same model on the files whose fingerprints are in
the table above — a check by the authors' side, not an independent verdict.

## 10. What the operator asked for, as patterns

`references/operator_revision_patterns.md` lists the operator's revision requests from one
partnership pitch, generalised, with what changed and which section above states the rule; and the
questions asked while rehearsing, with where each answer belongs.

## Provenance

Extracted from one partnership pitch deck with details and appendix pages. The kit is that deck's kit
with the talk-specific parts removed. Names of the partner, people, identifiers, dates, sizes of the
event and amounts are deliberately absent.

Reviewed in three multi-LLM review rounds (three outside seats and three personas); round 3 raised no
new blocking finding and the operator closed the review there. The wording fixes made after round 3
(closing the one carried-over item, and four advisories) were not re-reviewed.

## Backlog (not in this version)

- Touch navigation for phone readers arriving by QR (now: tap = next only; the back button leaves).
- A demo-script skeleton implementing § 6.
- `check.py` coverage of the cover title, narrow pills and shifted groups.
- `make_public.py`: rewriting links inside companion pages; refusing credential patterns even in `VERBATIM` pages;
  links to local files not listed in `RELINK`; unquoted or upper-case `href`; two runs within one second.
