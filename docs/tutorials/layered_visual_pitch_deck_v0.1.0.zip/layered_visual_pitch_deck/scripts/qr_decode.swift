// Decode QR codes in a PNG (macOS, CoreImage): swift qr_decode.swift /abs/path/shot.png
import CoreImage
import Foundation
let url = URL(fileURLWithPath: CommandLine.arguments[1])
let img = CIImage(contentsOf: url)!
let det = CIDetector(ofType: CIDetectorTypeQRCode, context: nil, options: [CIDetectorAccuracy: CIDetectorAccuracyHigh])!
for f in det.features(in: img) { if let q = f as? CIQRCodeFeature { print(q.messageString ?? "nil") } }
