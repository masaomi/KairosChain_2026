"""Build the public copy of a deck: drop presenter-only lines, rename linked pages, refuse local traces.

Edit the settings below and run `python3 make_public.py`. Each run writes a NEW folder public_out_<time>/,
so files from an earlier run are never published by mistake. The operator copies that folder's files to
the web server; afterwards, fetch each URL and compare it byte for byte with the folder.
The cover QR must encode <host>/<NAME>.html.
"""
import pathlib
import re
import shutil
import sys
import time

DECK = "deck.html"                  # the presenter's deck
NAME = "my_talk"                    # public file name stem
RELINK = {}                         # local companion pages -> public names, e.g. {"demo.html": "my_talk_demo.html"}
PRESENTER_ONLY = []                 # exact HTML snippets to drop (run commands, key-file paths, local paths)
VERBATIM = set()                    # companion pages shown verbatim (e.g. a signed record): traces are listed, not refused
FORBIDDEN = ("~/", "/Users/", "/home/", "/Volumes/", "/tmp/", "file://", "_key", "api_key", "token=")


def fail(msg):
    sys.exit(f"[refused] {msg}")


deck = pathlib.Path(DECK).read_text(encoding="utf-8")
pages = {}
for local in RELINK:
    p = pathlib.Path(local)
    if not p.is_file():
        fail(f"companion page {local} does not exist")
    pages[local] = p.read_bytes().decode("utf-8", errors="replace")  # for scanning only; copied as bytes below
for snippet in PRESENTER_ONLY:
    if deck.count(snippet) != 1:
        fail(f"presenter-only snippet not found exactly once: {snippet[:60]}")
    deck = deck.replace(snippet, "")
for local, public in RELINK.items():
    deck = re.sub(r'(href|src)=(["\'])(\./)?' + re.escape(local) + r'(#[^"\']*)?\2',
                  lambda m: f'{m.group(1)}={m.group(2)}{public}{m.group(4) or ""}{m.group(2)}', deck)
    if re.search(r'(?:href|src)=["\'](?:[^"\']*/)?' + re.escape(local) + r'(?:[#?][^"\']*)?["\']', deck):
        fail(f"a link to {local} was not renamed")  # any other form left over
for bad in FORBIDDEN:
    if bad in deck:
        fail(f"local trace left in the public deck: {bad!r}")
for local, text in pages.items():
    hits = [bad for bad in FORBIDDEN if bad in text]
    if hits and local not in VERBATIM:
        fail(f"local trace in companion page {local}: {hits}")
    if hits:
        print(f"[check by eye] verbatim page {local} contains {hits}")

out = pathlib.Path(f"public_out_{time.strftime('%Y%m%d_%H%M%S')}")
out.mkdir()
(out / f"{NAME}.html").write_text(deck, encoding="utf-8")
for local, public in RELINK.items():
    shutil.copyfile(local, out / public)  # byte for byte: a verbatim record keeps the bytes its fingerprint covers
for f in sorted(out.iterdir()):
    print(f, f.stat().st_size)
