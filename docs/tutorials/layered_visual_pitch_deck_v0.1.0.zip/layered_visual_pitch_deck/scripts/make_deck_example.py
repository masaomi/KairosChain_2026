"""Smallest deck in the three-layer form: cover, one main slide, its details page, one appendix page.

Run:  python3 make_deck_example.py && python3 check.py deck.html && python3 render.py deck.html
Copy this file to make_deck.py, keep the shapes, replace the content.
File order matters: all main slides first, then details pages, then appendix pages (arrow keys follow the file).
"""
import hashlib
import kit
from kit import page, vslide, hslide, qr_svg
from viz import T, A, doc, fingerprint, arrow_path, pill, badge, NAVY, ORANGE, WHITE

kit.FOOT_TITLE = "Deck title · Venue · Date"
PUBLIC_URL = "https://example.org/my_talk.html"   # must equal <host>/<NAME>.html in make_public.py
MAIN_TOTAL = 2                                              # main slides only; details and appendix are not counted


def pg(n):
    return f"{n} / {MAIN_TOTAL}"


def cover():
    return (f'<section class="slide s-title" data-key="m1"><div class="mh">'
            f'<h1>One claim, said as a title<span class="h1d">Who · with whom</span></h1>'
            f'<p class="sub">Speaker · Affiliation · Date</p></div>'
            f'<a class="qr" href="{PUBLIC_URL}" target="_blank" style="position:absolute;right:48px;top:56px;display:flex;'
            f'flex-direction:column;align-items:center;gap:8px;text-decoration:none">'
            f'<span style="background:#fff;border-radius:10px;padding:6px;line-height:0">{qr_svg(PUBLIC_URL)}</span>'
            f'<span style="color:#c3ccd6;font-size:14px;font-weight:600">these slides</span></a>'
            f'<div class="foot"><span class="ft">{kit.FOOT_TITLE}</span><span class="pg">{pg(1)}</span></div></section>')


def main_slide():
    """Main layer: the title states the claim; one figure carries it; animation order = speaking order."""
    b = []
    b.append(A(doc(260, 250, 1.6) + T(260, 360, "a record", 22, NAVY, weight=800), "a-pop", 0.1))
    b.append(arrow_path("M340 250 H520", NAVY, 4, cls="a-draw", delay=0.5))
    b.append(A(fingerprint(620, 250, 2.0) + T(620, 360, "its fingerprint", 22, NAVY, weight=800), "a-pop", 0.9))
    b.append(arrow_path("M720 250 H900", NAVY, 4, cls="a-draw", delay=1.3))
    b.append(A(badge(1000, 250, 48, "ok") + T(1000, 360, "anyone can check", 22, NAVY, weight=800), "a-stamp", 1.7))
    # a status pill says what is NOT done yet, on the slide itself, not only in the notes
    b.append(A(pill(640, 470, 360, 38, "public log: not deployed yet", ORANGE, WHITE, 17), "a-fade", 2.2))
    return vslide("m2", "A fingerprint lets anyone check that a record has not changed", "".join(b), pg(2), detail="d2")


def details_page():
    """Details layer: one per claim-bearing main slide, reached by its 'details' link, with a way back."""
    body = ('<div class="two"><div class="box"><h3>What was checked</h3><ul>'
            '<li>Each number on the main slide, with its denominator and its source row in SOURCES.md.</li>'
            '<li>How to run the check yourself, without an account.</li></ul></div>'
            '<div class="box o"><h3>What it does not show</h3><ul>'
            '<li>That the content is correct: a fingerprint only shows it did not change.</li>'
            '<li>Who wrote it: that needs a signature, not a fingerprint.</li></ul></div></div>'
            '<p class="note">Longer background: <a href="#b1">appendix B1</a>.</p>')
    return hslide("d2", "Details · slide 2", "A fingerprint lets anyone check that a record has not changed", body, "D2", back="m2")


def sha(text):
    """First 8 hex digits of the SHA-256 of a text: computed, never typed in."""
    return hashlib.sha256(text.encode()).hexdigest()[:8]


def appendix_page():
    """Appendix layer: the answer to a question you expect, drawn, found by pressing the up arrow."""
    b = [A(T(60, 60, "Change one letter, and the SHA-256 fingerprint changes completely", 24, NAVY, "start", 800), "a-fade", 0.0),
         A(T(60, 140, f"ACGTACGTAC  →  {sha('ACGTACGTAC')}…", 22, NAVY, "start", 700)
           + T(60, 190, f"ACGTACGTAA  →  {sha('ACGTACGTAA')}…", 22, ORANGE, "start", 700), "a-fade", 0.4),
         '<a href="#m2">' + A(pill(1150, 560, 170, 32, "back to slide 2", "#fff", NAVY, 15, NAVY), "a-fade", 0.8) + "</a>"]
    return vslide("b1", "Appendix B1 · A fingerprint", "".join(b), "B1")


if __name__ == "__main__":
    html = page("One claim, said as a title", [cover(), main_slide(), details_page(), appendix_page()])
    open("deck.html", "w", encoding="utf-8").write(html)
    print("deck.html written")
