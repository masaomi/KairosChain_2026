# Operator revision requests that made the deck clearer

Source: the operator's requests while one partnership pitch was prepared and revised, generalised.
Names of people, companies, products, identifiers, URLs, dates of the event and amounts are left out
on purpose. Each row is a request, what changed, and the section of the main entry that states the rule.

## Requests during the final editing session

| Operator asked for | What changed on the deck | Rule |
|---|---|---|
| One line under the blockchain explainer's punchline: using it for signatures is less regulated than coins or NFTs | A smaller line under "a notary's stamp — not money": lighter regulation, because no money changes hands | § 2 punchline follow-up. The limit (data-protection law still applies to what a record holds) belongs on the details page; in that deck it reached only the notes — a gap found in review |
| A link to the open-source repository, and total downloads with a growth chart in a corner | Corner block: the registry total on the day, a cumulative curve from a public tracker, a link pill | § 2 social proof |
| Icon-style pictures of the two gods behind an abstract distinction (clock time vs the decisive moment) | Two generated icons as a matching pair, coloured to the deck, beside each panel's heading | § 2 personified pairs |
| A QR code on the cover, and the deck on the project website like earlier decks | Cover QR to the public URL; public copy built, copied by the operator, checked byte for byte over HTTPS | § 7 |
| A chat assistant on every slide, answering from the deck's content | Dropped by the operator the same day: it needed a production server change before the talk | Do not add features that need a production change on the day of the talk |
| "Two of the eight planted mistakes went uncaught — are they the same kind?", then: count only the real miss | The case declared out of reach in time-stamped expectations before the run became a grey dashed card; the headline became 6 / 7 with all 8 cards still shown | § 3 "a test case left out of a count" |
| A phrase saying we actually checked the 1,000 papers ourselves | "We checked 1,000 real … preprints", with a line naming where from, which months, and which of our tools read them | § 3 own measurement (say "read by a model" when it was) |
| Press the up arrow to list every slide, search and jump | The searchable index, opened with ↑; details pages labelled by their main slide ("10 det") | § 1 |
| The verify script should say "did not answer" rather than crash when a third party is down | That step catches the error, prints SKIP with the reason, and the remaining steps run | § 6 |
| An appendix drawing the three differences between our private chain and Git | One drawn page: the same mechanism on top, three rows of differences, a closing line that the same could be built around Git | § 4 hardest question |
| Say on the demo slide that its results are not yet on our public log | The bottom pill: "answers fixed in advance (time-stamped) · results not yet on our public log" | § 3 "done but not yet recorded" |

## Questions the operator asked while rehearsing

| Question | Where the answer belongs |
|---|---|
| Do the headline percentages come from our own survey? | Slide: the population each borrowed number was measured on (none was from the talk's own field); details page: the references, and which number is ours |
| What is the difference between demo 1 and demo 3? | Notes: demo 1 shows the mechanism (only we can run it), demo 3 shows independence (anyone can) |
| Does a zkVM certificate (a proof that a program ran correctly, checkable without the data) prove reproducibility? | Appendix page: it proves one computation, not that the analysis reruns elsewhere |
| Does "0 pin the exact container" mean no paper guaranteed full reproduction? | Slide: the narrower wording ("no paper's text quotes a container digest"); details page: read by a model, and a digest pins only the software. In that deck the main slide kept the broader wording — a gap found in review |
| Can I find our record on a block explorer? | Details page: only the bundle's fingerprint is in the block; the link to our record is the proof file, checkable in a browser |

## Other changes made while preparing the same deck

- Blockchain explainer: picture only — a chain of pages that breaks when one is edited; coin = money vs stamp = signature.
- Abstract categories get one everyday example each (evidential: a log; constitutive: a certificate, a marriage registration).
- Links stay on slides even when the audience cannot open them yet.
- Two-act slides: "Normally …" then "But …".
- "Tested on … · not deployed yet" pills wherever something is built but not running.
