# Importing `layered_visual_pitch_deck` into your KairosChain

An L1 knowledge entry with a runnable kit: how to build a talk deck that is understood in one pass
(main slides, details pages, an appendix found with the up arrow, honesty on the slide). The deck
from our hands-on session was built with it.

Requirements: kairos-chain (tested with 3.93.0); Python 3 with `playwright` (then
`python3 -m playwright install chromium`), `qrcode` and `Pillow`; macOS for `qr_decode.swift`.
The section "要約（人向け）" at the top of the entry is a short Japanese summary; the rest is English.
It builds on `html_slide_deck_authoring`, which ships with the gem (installed by `kairos-chain init`
and `kairos-chain upgrade --apply`).

## Steps

1. Unzip this folder to `~/Downloads/layered_visual_pitch_deck/`.
2. In Claude Code, in your project:
   "Create the L1 knowledge entry layered_visual_pitch_deck from
   ~/Downloads/layered_visual_pitch_deck/layered_visual_pitch_deck.md, with create_subdirs true."
   The agent calls `knowledge_update(command: "create", ...)`; the entry's hash is recorded on your chain.
3. Copy the kit into the entry (replace the path with your data directory):

   ```sh
   K=~/work/my-project/.kairos/knowledge/layered_visual_pitch_deck
   SRC=~/Downloads/layered_visual_pitch_deck
   cp $SRC/scripts/* $K/scripts/
   cp $SRC/assets/* $K/assets/
   cp $SRC/references/* $K/references/
   ```

   The chain records the `.md` only. The kit files are pinned by the SHA-256 table in § 9 of the
   entry. Check them:

   ```sh
   cd $K/scripts && for f in *.py *.swift; do echo "$(shasum -a 256 $f | cut -c1-16)  $f"; done
   ```

   Each 16-character prefix must equal the one in § 9.
4. Try it, in a scratch folder (the kit writes `deck.html` and `shots/` where it runs):

   ```sh
   mkdir -p ~/tmp/deck_try && cp $K/scripts/* ~/tmp/deck_try/ && cd ~/tmp/deck_try
   python3 make_deck_example.py && python3 check.py deck.html     # expect 0 issues on 4 pages
   python3 render.py deck.html 1                                  # PNG in shots/
   ```

5. To start your own deck, ask Claude Code to "use the layered_visual_pitch_deck knowledge" for it.
