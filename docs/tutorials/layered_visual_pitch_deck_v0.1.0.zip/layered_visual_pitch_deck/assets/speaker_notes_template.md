# Speaker notes — <talk title>, <date> (<N> main slides, ~<M> min + Q&A)

Each slide: the one sentence to land, what to do on screen, what not to say.
Keep the clock visible; demos are where time leaks.

| # | Slide | Time | Land this | Do / avoid |
|---|---|---|---|---|
| 1 | <title> | 0:30 | "<one sentence, in the words you will actually say>" | <what to show; what not to claim> |
| 2 | <title> | 1:30 | "<…>" | <numbers: say the denominator; the source row is in SOURCES.md> |

## Never say

- <a claim stronger than what was measured, e.g. "unregulated" when the slide says "lighter regulation">
- <a status nobody has confirmed, e.g. a certification or compliance claim you cannot point to>

## Questions we expect

Grouped by who asks. Each answer: one sentence first, then where in the deck to point (press ↑ and type a word).

| # | Question | Answer | Point to / do not say |
|---|---|---|---|
| D1 | <developer question> | <answer> | <appendix page> |
| M1 | <management question> | <answer> | <…> |
| G1 | <the question everyone asks, e.g. "isn't that just Git?"> | <concede what is the same, then the differences> | <details page; do not attack the other tool> |
