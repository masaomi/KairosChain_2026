# Sources — <talk title>

One row per number, quotation or asset on a slide. If a number has no row, it does not go on the slide.

| Slide | What appears | Where it comes from (and how it was measured) |
|---|---|---|
| 2 | "<n>% of <N> <things>" | <published paper, its table, and its reference number in our own write-up> |
| 3 | "<k> of <N>" | <our own measurement: which corpus, which tool, which date> |
| 5 | "<count> downloads" | <registry API and the date it was fetched; what the count includes (downloads ≠ users)> |
| 6 | icons | <generated with which tool, on which date, from a text description only; where the originals are kept> |
